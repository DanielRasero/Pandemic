import './App.css';
import React, {Component} from 'react';

 class App extends Component{

   constructor(props) {
     super(props);
     this.state={
       biocenosis : [['P','P','G','H','H','R'],
         ['P','P','G','H','H','G','H'],
         ['P','G','M','H','H','G','H','H'],
         ['G','R','M','H','G','G'],
         ['R','R','H','H','G','P']],

       newBiocenosis:[['P','P','G','H','H','R'],
         ['P','P','G','H','H','G','H'],
         ['P','G','M','H','H','G','H','H'],
         ['G','R','M','H','G','G'],
         ['R','R','H','H','G','P']],
       humans:0,

     }
   }


   contadorHumanos(contador){

       for (let i = 0; i < this.state.biocenosis.length; i++) {

           for (let j = 0; j < this.state.biocenosis.length[i]; j++) {


               if (this.state.biocenosis.length[i] instanceof Array){

                   this.contadorHumanos(contador);

               }else {

                   if (this.state.biocenosis.length[i][j]== 'H'){

                         contador++;

                   }

               }

           }

       }

       this.state.humans= contador;


   }

   pandemic(fila,columna,array){

       if (array[fila][columna]=== 'M'){

           array[fila][columna]=  array[fila][columna].toLowerCase();

           if(array[fila][columna+1]=== 'H' && (columna< array[fila].length)){

               this.pandemic(fila,columna+1,array);

           }else if(array[fila][columna-1]=== 'H' && (columna> 0)){

               this.pandemic(fila,columna-1,array);

           }else if(array[fila+1][columna]=== 'H' && (fila< array.length)){

               this.pandemic(fila+1,columna,array);

           }else if(array[fila-1][columna]=== 'H' && (fila> 0)){

               this.pandemic(fila-1,columna,array);
           }
           this.state.newBiocenosis= array;

       }else if(array[fila][columna]=== 'H'){

           array[fila][columna]= "";
           this.state.newBiocenosis= array;
       }



       if(array[fila][columna+1]=== array[fila][columna] && (columna< array[fila].length)){

           this.pandemic(fila,columna+1,array);

       }else if(array[fila][columna-1]=== array[fila][columna] && (columna> 0)){

           this.pandemic(fila,columna-1,array);

       }else if(array[fila+1][columna]=== array[fila][columna] && (fila< array.length)){

           this.pandemic(fila+1,columna,array);

       }else if(array[fila-1][columna]=== array[fila][columna] && (fila> 0)){

           this.pandemic(fila-1,columna,array);
       }


   }

  render() {

       var array= [['P','P','G','H','H','R'],
           ['P','P','G','H','H','G','H'],
           ['P','G','M','H','H','G','H','H'],
           ['G','R','M','H','G','G'],
           ['R','R','H','H','G','P']];
      var contador= 0;

    return (
        <div className="App">

            {this.contadorHumanos(contador)}

            <p>Humanos:  {this.state.humans}</p>

          <Fila array={this.state.newBiocenosis} />
            {console.log(array)}

          <br/>
            <br/>
            <br/>
            <br/>
            <button onClick={this.pandemic(2,2,array)}>Pandemia</button>

        </div>
    );
  }


}

function Fila(props) {

     return( props.array.map(e=> <p key={e}><Botonera array={e} /></p>));


}

function Botonera(props) {

    return( props.array.map(e=>  <button>{e}</button>));


}

export default App;
